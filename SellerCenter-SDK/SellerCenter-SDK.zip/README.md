# api-sellercenter-linio
Conexión con la API SellerCenter con usuarios de Linio
